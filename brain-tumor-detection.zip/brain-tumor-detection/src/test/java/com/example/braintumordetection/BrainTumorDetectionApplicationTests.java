package com.example.braintumordetection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrainTumorDetectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
